<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="https://fonts.googleapis.com/css2?family=Fondamento:ital@1&display=swap" rel="stylesheet">
        <link href="style.css" rel="stylesheet">
        <script src="java.js"></script>
        <style>
              body{
        background-image: url(./images/1.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        height: 100%;
      margin: 0;        
      }
      .footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color:white;
    color: black;
    text-align: center;
  }
  .footer p{
    margin: 10px;
  }

        </style>
    </head>
    <body>
        <div>
            <div id="navbar-main">
               <div id="title"> <div>Sistema Wehbsaiht</div></div>
                <div id="navbar-items"><a href="home.html"><div id="item"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-house" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M2 13.5V7h1v6.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V7h1v6.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5zm11-11V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
                    <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>
                  </svg>&nbsp&nbspHOME</a></div>
                  <div id="item"><a href="portal.html"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-at" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z"/>
                  </svg>&nbsp&nbspPORTAL</a></div>
                <div id="item"><a href="about.html"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-file-person" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M4 1h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm0 1a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H4z"/>
                    <path d="M13.784 14c-.497-1.27-1.988-3-5.784-3s-5.287 1.73-5.784 3h11.568z"/>
                    <path fill-rule="evenodd" d="M8 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                  </svg>&nbsp&nbspABOUT</a></div>
             
                <div id="item"><a href="admissions.html"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-door-open-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M1.5 15a.5.5 0 0 0 0 1h13a.5.5 0 0 0 0-1H13V2.5A1.5 1.5 0 0 0 11.5 1H11V.5a.5.5 0 0 0-.57-.495l-7 1A.5.5 0 0 0 3 1.5V15H1.5zM11 2v13h1V2.5a.5.5 0 0 0-.5-.5H11zm-2.5 8c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z"/>
                  </svg>&nbsp&nbspADMISSION</a></div>
              
                <div id="item"><a href="contactus.html"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-phone" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M11 1H5a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM5 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H5z"/>
                    <path fill-rule="evenodd" d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
                  </svg>&nbsp&nbspCONTACT US</a></div>
                </div>
                <div id="navbar-toggle">
                    <button style="border-style:none ;border-radius: 5px;" onclick="myNav()"><svg width="30px" height="30px" viewBox="0 0 16 16" class="bi bi-bar-chart-steps" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                      <path fill-rule="evenodd" d="M.5 0a.5.5 0 0 1 .5.5v15a.5.5 0 0 1-1 0V.5A.5.5 0 0 1 .5 0z"/>
                      <rect width="5" height="2" x="2" y="1" rx=".5"/>
                      <rect width="8" height="2" x="4" y="5" rx=".5"/>
                      <path d="M6 9.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-6a.5.5 0 0 1-.5-.5v-1zm2 4a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-7a.5.5 0 0 1-.5-.5v-1z"/>
                    </svg></button>
                    <div id="nav-toggle-list">
                        <p><a href="home.html"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-house" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M2 13.5V7h1v6.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V7h1v6.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5zm11-11V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
                            <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>
                          </svg>&nbsp&nbspHOME</a></p>
                        <p><a href="about.html"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-file-person" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4 1h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2zm0 1a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H4z"/>
                            <path d="M13.784 14c-.497-1.27-1.988-3-5.784-3s-5.287 1.73-5.784 3h11.568z"/>
                            <path fill-rule="evenodd" d="M8 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                          </svg>&nbsp&nbspABOUT</a></p>
                        <p><a href="academics.html"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-book-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.261 13.666c.345.14.739-.105.739-.477V2.5a.472.472 0 0 0-.277-.437c-1.126-.503-5.42-2.19-7.723.129C5.696-.125 1.403 1.56.277 2.063A.472.472 0 0 0 0 2.502V13.19c0 .372.394.618.739.477C2.738 12.852 6.125 12.113 8 14c1.875-1.887 5.262-1.148 7.261-.334z"/>
                          </svg>&nbsp&nbspACADEMICS</a></p>
                        <p><a href="admissions.html"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-door-open-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M1.5 15a.5.5 0 0 0 0 1h13a.5.5 0 0 0 0-1H13V2.5A1.5 1.5 0 0 0 11.5 1H11V.5a.5.5 0 0 0-.57-.495l-7 1A.5.5 0 0 0 3 1.5V15H1.5zM11 2v13h1V2.5a.5.5 0 0 0-.5-.5H11zm-2.5 8c-.276 0-.5-.448-.5-1s.224-1 .5-1 .5.448.5 1-.224 1-.5 1z"/>
                          </svg>&nbsp&nbspADMISSIONS</a></p>
                        <p><a href="portal.html"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-at" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z"/>
                          </svg>&nbsp&nbspPORTAL</a></p>
                        <p><a href="contactus.html"><svg width="20px" height="20px" viewBox="0 0 16 16" class="bi bi-phone" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M11 1H5a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zM5 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H5z"/>
                            <path fill-rule="evenodd" d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
                          </svg>&nbsp&nbspCONTACT US</a></p>
                    </div>
                </div>
          </div>
    <div id="portal-title">
      <i><h1 id="pt1">ADMISSIONS</h1></i>
    </div>
    <div>
      <div id="academics">
       
          <table style="width:100%;position: relative; margin-bottom: 20px;">
            
                <th id="portal-forms">
                    <form  action="connect.php" method="post">
                    <div>
                        <table id="ad-login" align="center">
                          <tr>
                            <td class="stdname" ><label for="sname">Name of the Student</label></td>
                            <td><input type="text" id="txtname" placeholder="Enter Student Name" size="30" name="sname" required/></td>
                        </tr>
                        <tr>
                            <td class="fname"><label for="fname">Father Name</label></td>
                            <td><input type="text" id="txtname" placeholder="Enter Father Name" size="30" name="fname" required/></td>
                        </tr>
                        <tr>
                           <td class="mname"><label for="mname">Mother Name</label></td>
                           <td><input type="text" id="txtname" placeholder="Enter Mother Name" size="30" name="mname" required/></td>
                       </tr>
                       <tr>
                           <td class="dob"><label for="sdob">Date of birth</label></td>
                           <td><input type="text" id="txtdate" placeholder="dd/mm/yyyy" name="sdob" required/></td>
                       </tr>
                       <tr>
                        <td class="gender"><label for="sg">Gender</label></td>
                        <td><input type="text" id="ad-select" placeholder="M/F/OTHERS" size="30" name="sg" required/></td>
                    </tr>
                       <tr>
                           <td class="pmob"><label for="parphone">Parent mobile number</label></td>
                           <td><input type="text" id="txtmobile" placeholder="Enter mobile number" name="parphone" size="30" required/></td> 
                       </tr>
                       <tr>
                           <td class="smob"><label for="sphone">Student mobile number</label></td>
                           <td><input type="text" id="txtmobile" placeholder="Enter mobile number" name="sphone" size="30" required/></td>
                       </tr>
                       <tr>
                           <td class="pemail"><label for="fmail">Parent EmailId</label></td>
                           <td><input type="email" id="txtemail" placeholder="Enter e-mail Id" size="30" name="fmail" required/></td>
                       </tr>
                       <tr>
                           <td class="semail"><label for="smail">Student EmailId</label></td>
                           <td><input type="email" id="txtemail" placeholder="Enter e-mail Id" size="30" name="smail" required/></td>
                       </tr> 
                       <tr>
                           <td class="branch"><label for="sbranch">Branch</label></td>
                           <td><input type="text" id="ad-select" placeholder="Branch" size="30" name="sbranch" required/></td>
                       </tr>  
                          <tr>
                            <td align="center"  colspan="2"><input type="submit" style="background-color: black;color:white;"></td>
                          </tr>
                        </table>
                      </div>
                    </form>
                </th>
            
        </table>
       </div>
    </div>
    <hr style="margin-top: 30px;margin-bottom:30px"/>
    <div class="footer" style="display: flex;flex-direction: row;justify-content:space-between;align-items: center;">
      <div style="font-size: smaller;">
        @Copyrights Sistema Wehbsaiht
      </div>
      <div  style="font-size: smaller;display: flex;flex-direction: row;justify-content: center;">
        <p><h4>Designed and Developed by</h4></p>
        <p><h4>ASVS KRISHNA RAJESH</h4></p>
        <p><h4>AKSHITHA POKURI</h4></p>
        <p><h4>V.N.S.LIKHITHA</h4></p>
      </div>
      </div>
</body>
<script>
        var x = screen.width;
    var y = document.getElementById('navbar-toggle');
    var z = document.getElementById('navbar-items');
    if(x > 1200){
        y.style.display = 'none';
    }
    else{
        y.style.display = 'block';
        z.style.display = 'none';
    }

</script>
</html>
