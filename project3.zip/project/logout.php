<?php
session_start();
unset($_SESSION['roll']);
unset($_SESSION['password']);
header("Location:http://localhost:10080/project/home.html");





?>